const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Connect to MongoDB Atlas
mongoose.connect('mongodb+srv://<user>:<pass>@cluster0.mongodb.net/garage?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

// Schemas
const EmployeeSchema = new mongoose.Schema({ name: String, role: String, phone: String, email: String });
const ContactSchema = new mongoose.Schema({ name: String, vehicle: String, phone: String, email: String, message: String, date: { type: Date, default: Date.now } });
const CustomerSchema = new mongoose.Schema({ name: String, phone: String, email: String, vehicles: [String], serviceHistory: [{ date: Date, service: String, cost: Number }] });
const InvoiceSchema = new mongoose.Schema({ customerId: String, date: Date, services: [{ name: String, cost: Number }], total: Number });
const CostSchema = new mongoose.Schema({ description: String, amount: Number, date: Date });
const AdminSchema = new mongoose.Schema({ username: String, password: String });

const Employee = mongoose.model('Employee', EmployeeSchema);
const Contact = mongoose.model('Contact', ContactSchema);
const Customer = mongoose.model('Customer', CustomerSchema);
const Invoice = mongoose.model('Invoice', InvoiceSchema);
const Cost = mongoose.model('Cost', CostSchema);
const Admin = mongoose.model('Admin', AdminSchema);

// Middleware for authentication
const isAuthenticated = async (req, res, next) => {
    const { username, password } = req.body;
    const admin = await Admin.findOne({ username });
    if (admin && await bcrypt.compare(password, admin.password)) {
        next();
    } else {
        res.status(401).json({ message: 'Unauthorized' });
    }
};

// Create default admin (run once)
async function createDefaultAdmin() {
    const adminExists = await Admin.findOne({ username: 'admin' });
    if (!adminExists) {
        const hashedPassword = await bcrypt.hash('admin123', 10);
        await Admin.create({ username: 'admin', password: hashedPassword });
        console.log('Default admin created: username=admin, password=admin123');
    }
}
createDefaultAdmin();

// Contact form submission
app.post('/submit', async (req, res) => {
    const { name, vehicle, phone, email, message } = req.body;
    await Contact.create({ name, vehicle, phone, email, message });
    res.json({ message: 'Form submitted successfully!' });
});

// Admin login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const admin = await Admin.findOne({ username });
    if (admin && await bcrypt.compare(password, admin.password)) {
        res.json({ success: true });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
});

// Employee management
app.post('/employees', isAuthenticated, async (req, res) => {
    const { name, role, phone, email } = req.body;
    await Employee.create({ name, role, phone, email });
    res.json({ success: true });
});

app.get('/employees', isAuthenticated, async (req, res) => {
    const employees = await Employee.find();
    res.json(employees);
});

app.delete('/employees/:id', isAuthenticated, async (req, res) => {
    await Employee.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

// Customer management
app.post('/customers', isAuthenticated, async (req, res) => {
    const { name, phone, email, vehicles } = req.body;
    await Customer.create({ name, phone, email, vehicles: vehicles.split(','), serviceHistory: [] });
    res.json({ success: true });
});

app.get('/customers', isAuthenticated, async (req, res) => {
    const customers = await Customer.find();
    res.json(customers);
});

app.delete('/customers/:id', isAuthenticated, async (req, res) => {
    await Customer.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

// Contact management
app.get('/contacts', isAuthenticated, async (req, res) => {
    const contacts = await Contact.find();
    res.json(contacts);
});

app.delete('/contacts/:id', isAuthenticated, async (req, res) => {
    await Contact.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

// Financial management
app.post('/invoices', isAuthenticated, async (req, res) => {
    const { customerId, services } = req.body;
    const total = services.reduce((sum, s) => sum + Number(s.cost), 0);
    const invoice = await Invoice.create({ customerId, date: new Date(), services, total });
    await Customer.findByIdAndUpdate(customerId, { $push: { serviceHistory: { date: new Date(), service: services.map(s => s.name).join(', '), cost: total } } });
    res.json({ success: true });
});

app.post('/costs', isAuthenticated, async (req, res) => {
    const { description, amount } = req.body;
    await Cost.create({ description, amount, date: new Date() });
    res.json({ success: true });
});

app.get('/finances', isAuthenticated, async (req, res) => {
    const invoices = await Invoice.find();
    const costs = await Cost.find();
    const totalIncome = invoices.reduce((sum, inv) => sum + inv.total, 0);
    const totalCosts = costs.reduce((sum, c) => sum + c.amount, 0);
    const netProfit = totalIncome - totalCosts;
    res.json({ invoices, costs, totalIncome, totalCosts, netProfit });
});

module.exports = app;